package Task5;

public class Main2 {

	public static void main(String[] args) {
	Dog Z=new Dog();
	Z.makesound();
	}

}
