package Task5;

public class Main5 {

	 public static void main(String[] args) {
	        Person person = new Person("Mohsin");
	        System.out.println("Name: " + person.getName());
	    }
}
