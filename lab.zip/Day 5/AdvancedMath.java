package Task5;

public class AdvancedMath extends MathConstant {
	void newvalue() {
		double e=66 //error because of final keyword we dont inheritance and override
		System.out.println(e);
		}
		}

