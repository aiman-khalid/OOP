package Task5;

public class Main4 {

	public static void main(String[] args) {
		final double r = 3.14;
				Area A=new Area();
		A.calculateArea(5);
	}
}
