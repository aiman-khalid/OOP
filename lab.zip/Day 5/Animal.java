package Task5;

public class Animal {
final void makesound() {
	System.out.println("Animal make sounds");
}
}
