package Task5;

public class Area {
   double calculateArea(double r) {
	   double area = 3.14*(r*r);
        return area;
   }
}