package Task5;

public class Dog extends Animal {
	void makesound() {	//error because of final keyword we dont inheritance and override
		System.out.println("human make sounds");
	}
	}

