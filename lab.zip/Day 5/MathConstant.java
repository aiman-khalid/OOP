package Task5;

public class MathConstant {
void value() {
	final double e=2.718;
	System.out.println(e);
}
}
