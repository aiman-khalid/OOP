package Task5;

public class Main3 {

	public static void main(String[] args) {
		AdvancedMath M=new AdvancedMath();
		M.value();
	}
}
