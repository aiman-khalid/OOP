package lab;

public class Class_1 {
	
	void displayinfo(String name,int age) {
		System.out.println("Name "+name);
		System.out.println("Age "+age+"\n");
	}
}
