package lab;

public class Bank {
	double balance = 539.2;
	int accountno = 16;
	
	double add (double bal) {
		bal+=balance;
		return bal;
	}
}
