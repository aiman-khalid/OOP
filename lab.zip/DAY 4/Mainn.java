package lab4;

public class Mainn {

	public static void main(String[] args) {

	      employeee emp1 = new manager(); 	       
	     employeee emp2 = new developer();
	     employeee emp3 = new employeee();
	        
	        emp1.calculateSalary(); 
	        emp2.calculateSalary(); 
	        emp3.calculateSalary(); 
}

	

}
