package labTask;

public class thirdclass {
	
	public static void main (String[] args) {
    lightBulb bulb = new lightBulb();
    bulb.showStatus();
    bulb.turnOn();
    bulb.turnOff();
}
}
