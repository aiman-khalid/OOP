package labTask;

public class secondmain {
	public static void main (String[] args) {
		passwordManager pm = new passwordManager() ;
		pm.changePassword();
		pm.validatePassword();
	}
}
