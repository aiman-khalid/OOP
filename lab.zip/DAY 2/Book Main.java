package labTask;

public class main {
	public static void main (String[] args) {
		book book1 = new book () ;
		
		book1.showStatus();
		book1.returnBook();
		book1.issueBook();
	}
}
